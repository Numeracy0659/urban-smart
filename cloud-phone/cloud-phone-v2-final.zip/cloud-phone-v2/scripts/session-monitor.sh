#!/bin/bash
###############################################################################
# Cloud Android Phone - Session Monitor
# Enforces maximum session duration and triggers graceful shutdown
###############################################################################

set -euo pipefail

MAX_HOURS="${SESSION_MAX_HOURS:-6}"
MAX_SECONDS=$((MAX_HOURS * 3600))
START_TIME=$(date +%s)
CHECK_INTERVAL=60

echo "$(date) Session Monitor: Max duration = ${MAX_HOURS} hours"

while true; do
    sleep "${CHECK_INTERVAL}"
    
    CURRENT_TIME=$(date +%s)
    ELAPSED=$((CURRENT_TIME - START_TIME))
    REMAINING=$((MAX_SECONDS - ELAPSED))
    
    # Log remaining time
    HOURS=$((REMAINING / 3600))
    MINUTES=$(((REMAINING % 3600) / 60))
    echo "$(date) Session Monitor: Remaining = ${HOURS}h ${MINUTES}m"
    
    # Check if time is up
    if [ "${REMAINING}" -le 0 ]; then
        echo "$(date) Session Monitor: TIME LIMIT REACHED - Initiating shutdown"
        
        # Trigger graceful shutdown
        supervisorctl stop ws-scrcpy nport healthcheck 2>/dev/null || true
        sleep 5
        supervisorctl stop emulator 2>/dev/null || true
        sleep 5
        
        # Backup
        /usr/local/bin/backup-session.sh 2>/dev/null || true
        
        # Exit to trigger container shutdown
        exit 0
    fi
    
    # Warning at 30 minutes remaining
    if [ "${REMAINING}" -le 1800 ] && [ "${REMAINING}" -gt 1740 ]; then
        echo "$(date) Session Monitor: WARNING - Less than 30 minutes remaining!"
    fi
    
    # Warning at 1 hour remaining
    if [ "${REMAINING}" -le 3600 ] && [ "${REMAINING}" -gt 3540 ]; then
        echo "$(date) Session Monitor: WARNING - Less than 1 hour remaining!"
    fi
done
