#!/bin/bash
###############################################################################
# Cloud Android Phone - Quick Start (Local)
# PhantomLink Operations - Production v2.0
#
# Usage: ./start.sh [--no-tunnel] [--subdomain NAME] [--port PORT]
###############################################################################

set -euo pipefail

# Parse arguments
NO_TUNNEL=false
SUBDOMAIN=""
PORT=8000

while [[ $# -gt 0 ]]; do
    case $1 in
        --no-tunnel) NO_TUNNEL=true; shift ;;
        --subdomain) SUBDOMAIN="$2"; shift 2 ;;
        --port) PORT="$2"; shift 2 ;;
        --help)
            echo "Usage: ./start.sh [OPTIONS]"
            echo "  --no-tunnel     Skip NPort tunnel (local only)"
            echo "  --subdomain X   Custom NPort subdomain"
            echo "  --port X        Web interface port (default: 8000)"
            echo "  --help          Show this help"
            exit 0 ;;
        *) echo "Unknown option: $1"; exit 1 ;;
    esac
done

echo ""
echo "╔══════════════════════════════════════════════════════════════════╗"
echo "║                                                                  ║"
echo "║   ☁️   CLOUD ANDROID PHONE v2.0                                  ║"
echo "║       PhantomLink Operations                                     ║"
echo "║                                                                  ║"
echo "╚══════════════════════════════════════════════════════════════════╝"
echo ""

# Prerequisites
echo "=== Checking Prerequisites ==="

# Docker
if ! command -v docker &>/dev/null; then
    echo "✗ Docker not found. Install: https://docs.docker.com/get-docker/"
    exit 1
fi
echo "  ✓ Docker: $(docker --version | cut -d',' -f1)"

# KVM
if [ -e /dev/kvm ]; then
    echo "  ✓ KVM: Available"
    sudo chmod 666 /dev/kvm 2>/dev/null || true
else
    echo "  ⚠ KVM: Not available (slower)"
fi

# Node.js (for NPort)
if [ "${NO_TUNNEL}" = "false" ]; then
    if ! command -v node &>/dev/null; then
        echo "  ✗ Node.js required for NPort. Install: https://nodejs.org/"
        exit 1
    fi
    echo "  ✓ Node.js: $(node --version)"
fi

echo ""

# Build
echo "=== Building Image ==="
docker build -t cloud-android-phone:latest .
echo ""

# Start
echo "=== Starting Container ==="
docker run -d \
    --name cloud-phone \
    --privileged \
    --device /dev/kvm:/dev/kvm \
    -p "${PORT}:${PORT}" \
    -p 5555:5555 \
    -e DISPLAY_WIDTH=720 \
    -e DISPLAY_HEIGHT=1280 \
    -e RAM_SIZE=4096 \
    -e SCRCPY_WEB_PORT="${PORT}" \
    -e ARM_TRANSLATION=1 \
    -e ROOT_SETUP=1 \
    -e GAPPS_SETUP=1 \
    -e SESSION_MAX_HOURS=6 \
    -v cloud-phone-data:/home/androidusr/data \
    cloud-android-phone:latest

echo "  ✓ Container started"
echo ""

# Wait for boot
echo "=== Waiting for Android Boot ==="
for i in $(seq 1 300); do
    BOOT=$(docker exec cloud-phone /opt/android-sdk/platform-tools/adb -s emulator-5555 shell getprop sys.boot_completed 2>/dev/null || echo "0")
    if [ "${BOOT}" = "1" ]; then
        echo "  ✓ Boot completed after $((i * 2))s"
        break
    fi
    [ $i -eq 90 ] && echo "  ... 3 min elapsed"
    [ $i -eq 180 ] && echo "  ... 6 min elapsed"
    [ $i -eq 270 ] && echo "  ... 9 min elapsed"
    sleep 2
done

# Optimize
echo "=== Optimizing ==="
docker exec cloud-phone /opt/android-sdk/platform-tools/adb -s emulator-5555 shell settings put global window_animation_scale 0 2>/dev/null
docker exec cloud-phone /opt/android-sdk/platform-tools/adb -s emulator-5555 shell settings put global transition_animation_scale 0 2>/dev/null
docker exec cloud-phone /opt/android-sdk/platform-tools/adb -s emulator-5555 shell settings put global animator_duration_scale 0 2>/dev/null
echo "  ✓ Optimized"
echo ""

# Tunnel
TUNNEL_URL="http://localhost:${PORT}"
if [ "${NO_TUNNEL}" = "false" ]; then
    echo "=== Starting Tunnel ==="
    npm install -g nport 2>/dev/null || npm install -g --force nport
    
    SUB="${SUBDOMAIN:-caphone-$(date +%s | sha256sum | head -c 6)}"
    nport "${PORT}" -s "${SUB}" > /tmp/nport-cloud-phone.log 2>&1 &
    
    for i in $(seq 1 30); do
        sleep 3
        if grep -q "nport.link" /tmp/nport-cloud-phone.log 2>/dev/null; then
            TUNNEL_URL=$(grep -oP 'https://[a-zA-Z0-9.-]+\.nport\.link' /tmp/nport-cloud-phone.log | head -1)
            break
        fi
    done
    
    if echo "${TUNNEL_URL}" | grep -q "nport.link"; then
        echo "  ✓ Tunnel: ${TUNNEL_URL}"
    else
        echo "  ⚠ Tunnel failed - using local access"
    fi
fi

echo ""
echo "╔══════════════════════════════════════════════════════════════════╗"
echo "║                                                                  ║"
echo "║   🎉  YOUR CLOUD ANDROID PHONE IS READY!                        ║"
echo "║                                                                  ║"
echo "╠══════════════════════════════════════════════════════════════════╣"
echo "║                                                                  ║"
echo "║   🔗  URL:       ${TUNNEL_URL}                                  ║"
echo "║   📱  ADB:       adb connect localhost:5555                     ║"
echo "║   ⏱️   Duration:   Up to 6 hours                                  ║"
echo "║                                                                  ║"
echo "║   Open the URL in any browser!                                   ║"
echo "║                                                                  ║"
echo "╚══════════════════════════════════════════════════════════════════╝"
echo ""
echo "  To stop:  ./stop.sh"
echo "  To logs:  docker logs -f cloud-phone"
echo ""
