#!/bin/bash
###############################################################################
# Cloud Android Phone - Emulator Startup Script
# Boots the Android emulator with optimized settings
###############################################################################

set -euo pipefail

ADB=/opt/android-sdk/platform-tools/adb
EMULATOR=/opt/android-sdk/emulator/emulator

# Start ADB server
"${ADB}" start-server 2>&1 | tee -a /home/androidusr/logs/adb.log

# Check KVM availability
if [ -e /dev/kvm ]; then
    sudo chmod 666 /dev/kvm 2>/dev/null || true
    echo "$(date) KVM: Available - Hardware acceleration enabled"
    ACCEL_FLAG="-accel on"
else
    echo "$(date) KVM: Not available - Using software rendering"
    ACCEL_FLAG="-accel off"
fi

# Boot emulator with optimized flags
exec "${EMULATOR}" \
    -avd cloud_phone \
    -no-window \
    -no-snapshot-load \
    -no-snapshot-save \
    -no-audio \
    -no-boot-anim \
    -no-skin \
    -qemu \
    ${ACCEL_FLAG} \
    -show-kernel 2>&1
