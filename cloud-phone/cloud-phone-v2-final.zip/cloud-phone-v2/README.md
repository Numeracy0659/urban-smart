# ☁️ Cloud Android Phone v2.0

**A full Android phone running in your browser — on-demand, secure, ephemeral, zero cost.**

---

## What Is This?

Cloud Android Phone is a production-grade system that runs a complete Android device inside a Docker container, streams it to your browser using WebSocket-based H.264 encoding (ws-scrcpy), and exposes it via a secure public HTTPS URL (NPort). The entire system is orchestrated by GitHub Actions or GitLab CI, meaning it runs on-demand with zero ongoing infrastructure costs.

---

## Features

| Feature | Details |
|---|---|
| Full Android 14 (API 34) | Pixel 6 device profile with Google APIs |
| ARM App Support | `libndk_translation` runs 99% of Play Store apps |
| Browser Streaming | ws-scrcpy — H.264 over WebSocket, 60fps, multi-touch |
| Public URL | NPort tunnel — instant `https://*.nport.link` |
| Root Access | Magisk pre-installed |
| Google Apps | PICO GAPPS included |
| Session Persistence | Backup/restore between sessions |
| Security | Ephemeral tunnels, auto-cleanup, encrypted backups |
| Zero Cost | Runs on free CI/CD runners |

---

## Quick Start — Local

```bash
git clone <your-repo-url>
cd cloud-phone-v2
chmod +x start.sh stop.sh
./start.sh
```

Open the URL printed in the terminal. The browser interface provides full touch, keyboard, clipboard, and device rotation support.

---

## Quick Start — GitHub Actions

1. Push this repository to GitHub
2. Go to **Actions** tab
3. Click **"Run workflow"** with these options:

| Input | Recommended Value |
|---|---|
| Action | `start` |
| Android Version | `34` |
| Resolution | `720x1280` |
| RAM | `4096` |
| Root | `true` |
| Google Apps | `true` |
| Session Duration | `6` hours |

4. The workflow will output a public URL — open it in any browser

---

## Quick Start — GitLab CI

1. Push to GitLab
2. Go to **CI/CD > Pipelines**
3. Click **"Run pipeline"**

The pipeline builds, starts, tunnels, and monitors automatically.

---

## Architecture

```
┌─────────────────────────────────────────────────────┐
│                   CI/CD Runner                       │
│  ┌─────────────────────────────────────────────┐    │
│  │              Docker Container                │    │
│  │                                             │    │
│  │  ┌─────────────┐  ┌──────────────────────┐ │    │
│  │  │  Android 14  │  │   ws-scrcpy Server   │ │    │
│  │  │  (Emulator)  │◄─┤   Port 8000 (HTTP)   │ │    │
│  │  │  + GAPPS    │  │   H.264 / WebSocket  │ │    │
│  │  │  + Magisk   │  └──────────┬───────────┘ │    │
│  │  │  + ARM xlate│             │              │    │
│  │  └─────────────┘             │              │    │
│  │                              ▼              │    │
│  │                    ┌────────────────┐       │    │
│  │                    │   NPort Tunnel  │       │    │
│  │                    │  https://*.nport │       │    │
│  │                    └────────┬───────┘       │    │
│  └─────────────────────────────┼───────────────┘    │
│                                │                     │
└────────────────────────────────┼─────────────────────┘
                                 │
                                 ▼
                    ┌────────────────────┐
                    │   Your Browser     │
                    │  Any device, any   │
                    │  OS, full control  │
                    └────────────────────┘
```

---

## Configuration

### Environment Variables

| Variable | Default | Description |
|---|---|---|
| `DISPLAY_WIDTH` | `720` | Screen width in pixels |
| `DISPLAY_HEIGHT` | `1280` | Screen height in pixels |
| `RAM_SIZE` | `4096` | RAM allocated to emulator (MB) |
| `SCRCPY_WEB_PORT` | `8000` | Web interface port |
| `ROOT_SETUP` | `1` | Enable root/Magisk |
| `GAPPS_SETUP` | `1` | Install PICO GAPPS |
| `ARM_TRANSLATION` | `1` | Enable ARM app translation |
| `SESSION_MAX_HOURS` | `6` | Max session duration |

---

## Project Structure

```
cloud-phone-v2/
├── Dockerfile              # Multi-stage production build
├── docker-compose.yml      # Local orchestration
├── start.sh                # Local quick-start
├── stop.sh                 # Local stop + backup
├── .gitlab-ci.yml          # GitLab CI pipeline
├── .dockerignore
├── .gitignore
├── .github/
│   └── workflows/
│       └── cloud-phone.yml # GitHub Actions workflow
├── config/
│   ├── supervisord.conf    # Process management
│   └── ws-scrcpy-config.json
├── scripts/
│   ├── start-emulator.sh   # Emulator boot
│   ├── start-ws-scrcpy.sh  # Web server
│   ├── start-tunnel.sh     # NPort tunnel
│   ├── health-check-loop.sh # Health monitoring
│   ├── session-monitor.sh  # Session timeout
│   ├── backup-session.sh   # Data backup
│   └── restore-session.sh  # Data restore
├── docs/                   # Documentation
└── extras/                 # Files to push to device
```

---

## How It Works

1. **Build** — The Dockerfile creates an optimized image with Android SDK, emulator, ws-scrcpy, and NPort
2. **Start** — The container boots with KVM acceleration and starts the Android emulator
3. **Stream** — ws-scrcpy connects to the emulator via ADB and streams the display over WebSocket with H.264 encoding
4. **Tunnel** — NPort creates a secure HTTPS tunnel, exposing the web interface to the public internet
5. **Access** — You open the URL in any browser and control the full Android device
6. **Monitor** — A health check loop monitors the system and the tunnel process
7. **Backup** — When the session ends, data is backed up and encrypted

---

## Troubleshooting

**"KVM not available"** — The runner must support nested virtualization. GitHub Actions `ubuntu-latest` supports it. If not, the emulator falls back to software rendering (slower but functional).

**"Boot timeout"** — First boot can take 10-15 minutes. The workflow waits up to 10 minutes. Increase timeout if needed.

**"Tunnel failed"** — NPort requires Node.js 20+. Ensure it's installed. The fallback URL `http://localhost:8000` is always available for local access.

**"Black screen"** — Wait for boot completion. Check `docker logs cloud-phone` for progress.

---

## License

MIT — PhantomLink Operations
