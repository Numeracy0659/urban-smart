# Cloud Android Phone v2.0 — Complete Delivery

**PhantomLink Operations | Production-Grade Cloud Android System**

This document contains every file you need, organized for direct copy-paste deployment from Termux or any terminal.

---

## Quick Deploy Commands (Termux)

```bash
# Create project directory
mkdir -p cloud-phone/.github/workflows cloud-phone/config cloud-phone/scripts cloud-phone/docs cloud-phone/extras

# Copy each file below into its respective path
# Then push to GitHub:
cd cloud-phone
git init
git add .
git commit -m "Initial: Cloud Android Phone v2.0"
git remote add origin <your-repo-url>
git push -u origin main
```

---

## File 1: `Dockerfile`

```dockerfile
###############################################################################
# Cloud Android Phone - Production Dockerfile
# PhantomLink Operations v2.0
###############################################################################

FROM node:20-bookworm-slim AS builder

WORKDIR /build

RUN apt-get update && apt-get install -y --no-install-recommends \
    git python3 make g++ && \
    rm -rf /var/lib/apt/lists/*

RUN git clone --depth 1 https://github.com/NetrisTV/ws-scrcpy.git && \
    cd ws-scrcpy && \
    npm install && \
    npx tsc -b

FROM ubuntu:22.04

LABEL maintainer="PhantomLink Operations" \
      description="Cloud Android Phone - Full Android in a container" \
      version="2.0.0"

ENV DEBIAN_FRONTEND=noninteractive \
    LANG=C.UTF-8 \
    LC_ALL=C.UTF-8 \
    ANDROID_HOME=/opt/android-sdk \
    ANDROID_SDK_ROOT=/opt/android-sdk \
    PATH="/opt/android-sdk/platform-tools:/opt/android-sdk/emulator:/opt/android-sdk/tools:${PATH}" \
    DISPLAY_WIDTH=720 \
    DISPLAY_HEIGHT=1280 \
    RAM_SIZE=4096 \
    SCRCPY_WEB_PORT=8000 \
    ADB_PORT=5555 \
    ARM_TRANSLATION=1 \
    ROOT_SETUP=1 \
    GAPPS_SETUP=1 \
    SESSION_MAX_HOURS=6

# System Dependencies
RUN apt-get update && apt-get install -y --no-install-recommends \
    bash curl wget jq gnupg2 gpg-agent \
    ca-certificates dnsutils iputils-ping \
    qemu-kvm libvirt-clients bridge-utils \
    xvfb x11-xserver-utils x11-utils \
    openjdk-11-jdk-headless \
    lib32stdc++6 lib32gcc1 lib32z1 \
    alsa-utils \
    supervisor \
    tar gzip \
    procps net-tools sudo unzip && \
    rm -rf /var/lib/apt/lists/*

# Non-Root User
RUN groupadd -r androidusr && \
    useradd -r -g androidusr -d /home/androidusr -s /bin/bash -m androidusr && \
    usermod -aG sudo androidusr && \
    echo "androidusr ALL=(ALL) NOPASSWD:ALL" >> /etc/sudoers && \
    mkdir -p /home/androidusr/{logs,backup,data} && \
    chown -R androidusr:androidusr /home/androidusr

# Android SDK
RUN mkdir -p /opt/android-sdk && \
    cd /opt/android-sdk && \
    wget -q "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip" -O cmdline-tools.zip && \
    unzip -q cmdline-tools.zip && \
    mv cmdline-tools latest && \
    rm cmdline-tools.zip && \
    chmod -R 755 /opt/android-sdk

RUN yes | sdkmanager --licenses 2>/dev/null || true && \
    sdkmanager \
        "platform-tools" \
        "platforms;android-34" \
        "emulator" \
        "system-images;android-34;google_apis;x86_64" \
        "extras;google;google_play_services" 2>&1 | tail -5

# Create AVD
RUN avdmanager create avd \
    --force \
    --name cloud_phone \
    --package "system-images;android-34;google_apis;x86_64" \
    --device "pixel_6" \
    --tag google_apis \
    --abi x86_64 && \
    echo "hw.lcd.width=720" >> /root/.android/avd/cloud_phone.avd/config.ini && \
    echo "hw.lcd.height=1280" >> /root/.android/avd/cloud_phone.avd/config.ini && \
    echo "hw.lcd.density=320" >> /root/.android/avd/cloud_phone.avd/config.ini && \
    echo "hw.ramSize=4096" >> /root/.android/avd/cloud_phone.avd/config.ini && \
    echo "hw.gpu.enabled=yes" >> /root/.android/avd/cloud_phone.avd/config.ini && \
    echo "hw.gpu.mode=host" >> /root/.android/avd/cloud_phone.avd/config.ini && \
    echo "sdcard.size=2G" >> /root/.android/avd/cloud_phone.avd/config.ini

# Node.js 20
RUN curl -fsSL https://deb.nodesource.com/setup_20.x | bash - && \
    apt-get install -y nodejs && \
    rm -rf /var/lib/apt/lists/*

# ws-scrcpy
COPY --from=builder /build/ws-scrcpy /opt/ws-scrcpy
WORKDIR /opt/ws-scrcpy
RUN npm install --production 2>/dev/null || true

# NPort
RUN npm install -g nport@latest

# Project Files
COPY scripts/ /usr/local/bin/
COPY config/ /etc/cloud-phone/

RUN chmod +x /usr/local/bin/*.sh && \
    chown -R androidusr:androidusr /usr/local/bin /opt/ws-scrcpy /etc/cloud-phone

EXPOSE 8000 5555

HEALTHCHECK --interval=30s --timeout=10s --start-period=120s --retries=3 \
    CMD curl -f http://localhost:8000 || exit 1

CMD ["supervisord", "-c", "/etc/cloud-phone/supervisord.conf", "-n"]
```

---

## File 2: `docker-compose.yml`

```yaml
services:
  cloud-phone:
    container_name: cloud-android-phone
    build:
      context: .
      dockerfile: Dockerfile
    image: cloud-android-phone:latest
    restart: unless-stopped
    privileged: true
    devices:
      - /dev/kvm:/dev/kvm
    ports:
      - "8000:8000"
      - "5555:5555"
    volumes:
      - cloud-phone-data:/home/androidusr/data
      - cloud-phone-backup:/home/androidusr/backup
    environment:
      - DISPLAY_WIDTH=720
      - DISPLAY_HEIGHT=1280
      - RAM_SIZE=4096
      - SCRCPY_WEB_PORT=8000
      - ADB_PORT=5555
      - ARM_TRANSLATION=1
      - ROOT_SETUP=1
      - GAPPS_SETUP=1
      - SESSION_MAX_HOURS=6
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000"]
      interval: 30s
      timeout: 10s
      start_period: 120s
      retries: 3
    deploy:
      resources:
        limits:
          memory: 6G
          cpus: '4'

volumes:
  cloud-phone-data:
    driver: local
  cloud-phone-backup:
    driver: local
```

---

## File 3: `.github/workflows/cloud-phone.yml`

```yaml
name: ☁️ Cloud Android Phone

on:
  workflow_dispatch:
    inputs:
      action:
        description: 'Action'
        required: true
        default: 'start'
        type: choice
        options:
          - start
          - stop
      android_version:
        description: 'Android Version (API Level)'
        required: false
        default: '34'
        type: choice
        options:
          - '30'
          - '33'
          - '34'
      resolution:
        description: 'Screen Resolution'
        required: false
        default: '720x1280'
      ram_mb:
        description: 'RAM (MB)'
        required: false
        default: '4096'
      enable_root:
        description: 'Enable Root (Magisk)'
        required: false
        default: true
        type: boolean
      enable_gapps:
        description: 'Enable Google Apps (PICO)'
        required: false
        default: true
        type: boolean
      session_hours:
        description: 'Max Session Duration (hours)'
        required: false
        default: '6'

permissions:
  contents: read

jobs:
  start-phone:
    name: 📱 Start Cloud Phone
    if: github.event.inputs.action == 'start'
    runs-on: ubuntu-latest
    timeout-minutes: 360

    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Enable KVM
        run: |
          if [ -e /dev/kvm ]; then
            echo "KVM: Available"
            sudo chmod 666 /dev/kvm
          else
            echo "KVM: Not available (software rendering)"
          fi

      - name: Build Docker Image
        run: |
          docker build \
            --build-arg DISPLAY_WIDTH=$(echo "${{ github.event.inputs.resolution }}" | cut -dx -f1) \
            --build-arg DISPLAY_HEIGHT=$(echo "${{ github.event.inputs.resolution }}" | cut -dx -f2) \
            --build-arg RAM_SIZE=${{ github.event.inputs.ram_mb }} \
            -t cloud-android-phone:latest \
            .

      - name: Start Container
        run: |
          RES_W=$(echo "${{ github.event.inputs.resolution }}" | cut -dx -f1)
          RES_H=$(echo "${{ github.event.inputs.resolution }}" | cut -dx -f2)
          
          docker run -d \
            --name cloud-phone \
            --privileged \
            --device /dev/kvm:/dev/kvm \
            -p 8000:8000 \
            -p 5555:5555 \
            -e DISPLAY_WIDTH="${RES_W}" \
            -e DISPLAY_HEIGHT="${RES_H}" \
            -e RAM_SIZE="${{ github.event.inputs.ram_mb }}" \
            -e SCRCPY_WEB_PORT=8000 \
            -e ARM_TRANSLATION=1 \
            -e ROOT_SETUP=$(echo "${{ github.event.inputs.enable_root }}" | tr '[:upper:]' '[:lower:]') \
            -e GAPPS_SETUP=$(echo "${{ github.event.inputs.enable_gapps }}" | tr '[:upper:]' '[:lower:]') \
            -e SESSION_MAX_HOURS=${{ github.event.inputs.session_hours }} \
            cloud-android-phone:latest

      - name: Wait for Boot
        run: |
          for i in $(seq 1 300); do
            BOOT=$(docker exec cloud-phone /opt/android-sdk/platform-tools/adb -s emulator-5555 shell getprop sys.boot_completed 2>/dev/null || echo "0")
            if [ "${BOOT}" = "1" ]; then
              echo "✓ Boot completed after $((i * 2))s"
              exit 0
            fi
            [ $i -eq 90 ] && echo "  ... 3 min elapsed"
            [ $i -eq 180 ] && echo "  ... 6 min elapsed"
            [ $i -eq 270 ] && echo "  ... 9 min elapsed"
            sleep 2
          done
          echo "✗ Boot timeout"
          docker logs cloud-phone --tail 50
          exit 1

      - name: Optimize
        run: |
          docker exec cloud-phone /opt/android-sdk/platform-tools/adb -s emulator-5555 shell settings put global window_animation_scale 0
          docker exec cloud-phone /opt/android-sdk/platform-tools/adb -s emulator-5555 shell settings put global transition_animation_scale 0
          docker exec cloud-phone /opt/android-sdk/platform-tools/adb -s emulator-5555 shell settings put global animator_duration_scale 0
          docker exec cloud-phone /opt/android-sdk/platform-tools/adb -s emulator-5555 shell settings put system screen_off_timeout 2147483647

      - name: Start NPort Tunnel
        id: tunnel
        run: |
          npm install -g nport 2>/dev/null || npm install -g --force nport
          SUBDOMAIN="caphone-$(date +%s | sha256sum | head -c 6)"
          nport 8000 -s "${SUBDOMAIN}" > /tmp/nport.log 2>&1 &
          
          for i in $(seq 1 30); do
            sleep 3
            if grep -q "nport.link" /tmp/nport.log 2>/dev/null; then
              TUNNEL_URL=$(grep -oP 'https://[a-zA-Z0-9.-]+\.nport\.link' /tmp/nport.log | head -1)
              echo "url=${TUNNEL_URL}" >> "${GITHUB_OUTPUT}"
              exit 0
            fi
          done
          echo "url=http://localhost:8000" >> "${GITHUB_OUTPUT}"

      - name: Print Access
        run: |
          echo ""
          echo "╔══════════════════════════════════════════════════════════════════╗"
          echo "║   🎉  YOUR CLOUD ANDROID PHONE IS READY!                        ║"
          echo "╠══════════════════════════════════════════════════════════════════╣"
          echo "║   🔗  URL:  ${{ steps.tunnel.outputs.url }}                      ║"
          echo "║   📱  Android: API ${{ github.event.inputs.android_version }}     ║"
          echo "║   🖥️   Resolution: ${{ github.event.inputs.resolution }}          ║"
          echo "║   ⏱️   Duration: Up to ${{ github.event.inputs.session_hours }}h  ║"
          echo "╚══════════════════════════════════════════════════════════════════╝"

      - name: Keep Alive
        run: |
          while true; do
            BOOT=$(docker exec cloud-phone /opt/android-sdk/platform-tools/adb -s emulator-5555 shell getprop sys.boot_completed 2>/dev/null || echo "0")
            echo "[$(date -u)] Status: boot_completed=${BOOT}"
            sleep 300
          done

  stop-phone:
    name: 🛑 Stop Cloud Phone
    if: github.event.inputs.action == 'stop'
    runs-on: ubuntu-latest
    steps:
      - name: Stop
        run: |
          docker stop cloud-phone 2>/dev/null && docker rm cloud-phone 2>/dev/null || true
          echo "✓ Stopped"
```

---

## File 4: `.gitlab-ci.yml`

```yaml
stages:
  - build
  - start
  - access
  - monitor
  - cleanup

variables:
  DISPLAY_WIDTH: "720"
  DISPLAY_HEIGHT: "1280"
  RAM_SIZE: "4096"
  SCRCPY_WEB_PORT: "8000"
  CONTAINER_NAME: "cloud-phone"

build-phone:
  stage: build
  image: docker:24-dind
  services:
    - docker:24-dind
  variables:
    DOCKER_DRIVER: overlay2
  script:
    - docker build -t cloud-phone:${CI_PIPELINE_ID} .
  timeout: 30m

start-phone:
  stage: start
  image: docker:24-dind
  services:
    - docker:24-dind
  variables:
    DOCKER_DRIVER: overlay2
  script:
    - chmod 666 /dev/kvm 2>/dev/null || echo "KVM not available"
    - |
      docker run -d \
        --name ${CONTAINER_NAME} \
        --privileged \
        --device /dev/kvm:/dev/kvm \
        -p ${SCRCPY_WEB_PORT}:${SCRCPY_WEB_PORT} \
        -p 5555:5555 \
        -e DISPLAY_WIDTH=${DISPLAY_WIDTH} \
        -e DISPLAY_HEIGHT=${DISPLAY_HEIGHT} \
        -e RAM_SIZE=${RAM_SIZE} \
        -e SCRCPY_WEB_PORT=${SCRCPY_WEB_PORT} \
        -e ARM_TRANSLATION=1 \
        -e ROOT_SETUP=1 \
        -e GAPPS_SETUP=1 \
        cloud-phone:${CI_PIPELINE_ID}
    - |
      for i in $(seq 1 300); do
        BOOT=$(docker exec ${CONTAINER_NAME} /opt/android-sdk/platform-tools/adb -s emulator-5555 shell getprop sys.boot_completed 2>/dev/null || echo "0")
        if [ "${BOOT}" = "1" ]; then
          echo "✓ Boot completed after $((i * 2))s"
          break
        fi
        [ $i -eq 90 ] && echo "  ... 3 min elapsed"
        [ $i -eq 180 ] && echo "  ... 6 min elapsed"
        [ $i -eq 270 ] && echo "  ... 9 min elapsed"
        sleep 2
      done
    - |
      docker exec ${CONTAINER_NAME} /opt/android-sdk/platform-tools/adb -s emulator-5555 shell settings put global window_animation_scale 0
      docker exec ${CONTAINER_NAME} /opt/android-sdk/platform-tools/adb -s emulator-5555 shell settings put global transition_animation_scale 0
      docker exec ${CONTAINER_NAME} /opt/android-sdk/platform-tools/adb -s emulator-5555 shell settings put global animator_duration_scale 0
    - |
      SESSION_ID=$(date +%s | sha256sum | head -c 8)
      echo "SESSION_ID=${SESSION_ID}" >> phone.env
    - |
      npm install -g nport 2>/dev/null || npm install -g --force nport
      SUBDOMAIN="caphone-${SESSION_ID}"
      nport ${SCRCPY_WEB_PORT} -s "${SUBDOMAIN}" > /tmp/nport.log 2>&1 &
      for i in $(seq 1 30); do
        sleep 3
        if grep -q "nport.link" /tmp/nport.log 2>/dev/null; then
          TUNNEL_URL=$(grep -oP 'https://[a-zA-Z0-9.-]+\.nport\.link' /tmp/nport.log | head -1)
          echo "TUNNEL_URL=${TUNNEL_URL}" >> phone.env
          break
        fi
      done
  artifacts:
    reports:
      dotenv: phone.env
    expire_in: 1 hour

access-info:
  stage: access
  script:
    - echo "╔══════════════════════════════════════════════════════════════════╗"
    - echo "║   🎉  YOUR CLOUD ANDROID PHONE IS READY!                        ║"
    - echo "╠══════════════════════════════════════════════════════════════════╣"
    - echo "║   🔗  URL:  ${TUNNEL_URL}                                       ║"
    - echo "║   🆔  Session: ${SESSION_ID}                                    ║"
    - echo "╚══════════════════════════════════════════════════════════════════╝"

monitor-phone:
  stage: monitor
  script:
    - |
      while true; do
        BOOT=$(docker exec ${CONTAINER_NAME} /opt/android-sdk/platform-tools/adb -s emulator-5555 shell getprop sys.boot_completed 2>/dev/null || echo "0")
        echo "[$(date -u)] Status: boot_completed=${BOOT}"
        sleep 300
      done
  timeout: 6h

cleanup:
  stage: cleanup
  when: always
  script:
    - kill $(cat /tmp/nport.pid 2>/dev/null) 2>/dev/null || true
    - docker stop ${CONTAINER_NAME} 2>/dev/null || true
    - docker rm ${CONTAINER_NAME} 2>/dev/null || true
    - docker system prune -f 2>/dev/null || true
    - echo "✓ Done"
```

---

## File 5: `config/supervisord.conf`

```ini
[unix_http_server]
file=/var/run/supervisord.sock
chmod=0700

[supervisord]
logfile=/home/androidusr/logs/supervisord.log
logfile_maxbytes=50MB
logfile_backups=3
loglevel=info
pidfile=/var/run/supervisord.pid
nodaemon=true
user=root

[rpcinterface:supervisor]
supervisor.rpcinterface_factory = supervisor.rpcinterface:make_main_rpcinterface

[supervisorctl]
serverurl=unix:///var/run/supervisord.sock

[program:emulator]
command=/usr/local/bin/start-emulator.sh
user=androidusr
autostart=true
autorestart=true
startretries=3
startsecs=10
stopwaitsecs=30
priority=1
stdout_logfile=/home/androidusr/logs/emulator.log
stderr_logfile=/home/androidusr/logs/emulator-err.log

[program:ws-scrcpy]
command=/usr/local/bin/start-ws-scrcpy.sh
user=androidusr
autostart=true
autorestart=true
startretries=5
startsecs=5
stopwaitsecs=10
priority=2
stdout_logfile=/home/androidusr/logs/ws-scrcpy.log
stderr_logfile=/home/androidusr/logs/ws-scrcpy-err.log

[program:nport]
command=/usr/local/bin/start-tunnel.sh
user=androidusr
autostart=true
autorestart=true
startretries=3
startsecs=5
stopwaitsecs=10
priority=3
stdout_logfile=/home/androidusr/logs/nport.log
stderr_logfile=/home/androidusr/logs/nport-err.log

[program:healthcheck]
command=/usr/local/bin/health-check-loop.sh
user=androidusr
autostart=true
autorestart=true
startretries=2
startsecs=120
priority=10
stdout_logfile=/home/androidusr/logs/health.log

[program:session-monitor]
command=/usr/local/bin/session-monitor.sh
user=androidusr
autostart=true
autorestart=false
startretries=1
startsecs=5
priority=11
stdout_logfile=/home/androidusr/logs/session.log
```

---

## File 6: `scripts/start-emulator.sh`

```bash
#!/bin/bash
set -euo pipefail

ADB=/opt/android-sdk/platform-tools/adb
EMULATOR=/opt/android-sdk/emulator/emulator

"${ADB}" start-server 2>&1 | tee -a /home/androidusr/logs/adb.log

if [ -e /dev/kvm ]; then
    sudo chmod 666 /dev/kvm 2>/dev/null || true
    echo "$(date) KVM: Available"
    ACCEL_FLAG="-accel on"
else
    echo "$(date) KVM: Not available"
    ACCEL_FLAG="-accel off"
fi

exec "${EMULATOR}" \
    -avd cloud_phone \
    -no-window \
    -no-snapshot-load \
    -no-snapshot-save \
    -no-audio \
    -no-boot-anim \
    -no-skin \
    -qemu \
    ${ACCEL_FLAG} \
    -show-kernel 2>&1
```

---

## File 7: `scripts/start-ws-scrcpy.sh`

```bash
#!/bin/bash
set -euo pipefail

ADB=/opt/android-sdk/platform-tools/adb
PORT="${SCRCPY_WEB_PORT:-8000}"

echo "$(date) ws-scrcpy: Waiting for ADB device..."
while ! "${ADB}" -s emulator-5555 shell getprop sys.boot_completed 2>/dev/null | grep -q "1"; do
    sleep 5
done
echo "$(date) ws-scrcpy: Android boot completed"

"${ADB}" -s emulator-5555 tcpip 5555 2>/dev/null || true
sleep 2

cd /opt/ws-scrcpy
export ADBHOST=emulator-5555
exec node dist/index.js --port "${PORT}" --host 0.0.0.0 2>&1
```

---

## File 8: `scripts/start-tunnel.sh`

```bash
#!/bin/bash
set -euo pipefail

PORT="${SCRCPY_WEB_PORT:-8000}"
SESSION_ID="${SESSION_ID:-$(date +%s | sha256sum | head -c 6)}"
SUBDOMAIN="caphone-${SESSION_ID}"

echo "$(date) Tunnel: Waiting for ws-scrcpy..."
for i in $(seq 1 60); do
    if curl -s -o /dev/null -w "%{http_code}" "http://localhost:${PORT}" 2>/dev/null | grep -qE "^[2-4]"; then
        echo "$(date) Tunnel: Server ready"
        break
    fi
    sleep 3
done

echo "$(date) Tunnel: Starting NPort..."
exec nport "${PORT}" -s "${SUBDOMAIN}" 2>&1
```

---

## File 9: `scripts/health-check-loop.sh`

```bash
#!/bin/bash
set -euo pipefail

ADB=/opt/android-sdk/platform-tools/adb
PORT="${SCRCPY_WEB_PORT:-8000}"

while true; do
    BOOT=$("${ADB}" -s emulator-5555 shell getprop sys.boot_completed 2>/dev/null || echo "0")
    HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:${PORT}" 2>/dev/null || echo "000")
    echo "$(date) Health: boot=${BOOT} web=${HTTP_CODE}"
    
    if [ "${BOOT}" != "1" ]; then
        "${ADB}" start-server 2>/dev/null || true
    fi
    
    sleep 30
done
```

---

## File 10: `scripts/session-monitor.sh`

```bash
#!/bin/bash
set -euo pipefail

MAX_HOURS="${SESSION_MAX_HOURS:-6}"
MAX_SECONDS=$((MAX_HOURS * 3600))
START_TIME=$(date +%s)

echo "$(date) Session Monitor: Max = ${MAX_HOURS}h"

while true; do
    sleep 60
    
    ELAPSED=$(($(date +%s) - START_TIME))
    REMAINING=$((MAX_SECONDS - ELAPSED))
    
    HOURS=$((REMAINING / 3600))
    MINUTES=$(((REMAINING % 3600) / 60))
    echo "$(date) Remaining: ${HOURS}h ${MINUTES}m"
    
    if [ "${REMAINING}" -le 0 ]; then
        echo "$(date) TIME LIMIT - shutting down"
        supervisorctl stop ws-scrcpy nport healthcheck 2>/dev/null || true
        sleep 5
        supervisorctl stop emulator 2>/dev/null || true
        /usr/local/bin/backup-session.sh 2>/dev/null || true
        exit 0
    fi
done
```

---

## File 11: `scripts/backup-session.sh`

```bash
#!/bin/bash
set -euo pipefail

BACKUP_DIR="/home/androidusr/backup"
ADB=/opt/android-sdk/platform-tools/adb
SESSION_ID="${SESSION_ID:-$(date +%s | sha256sum | head -c 8)}"

mkdir -p "${BACKUP_DIR}"

echo "$(date) Backup: Starting [${SESSION_ID}]"

"${ADB}" -s emulator-5555 shell settings list global > "${BACKUP_DIR}/settings-global.txt" 2>/dev/null || true
"${ADB}" -s emulator-5555 shell pm list packages > "${BACKUP_DIR}/packages.txt" 2>/dev/null || true

if [ -d /root/.android/avd ]; then
    tar czf "${BACKUP_DIR}/avd-data.tar.gz" -C /root/.android avd/ 2>/dev/null || true
fi

cat > "${BACKUP_DIR}/session-manifest.json" <<EOF
{
  "session_id": "${SESSION_ID}",
  "backup_time": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "android_version": "14 (API 34)",
  "device": "pixel_6"
}
EOF

echo "$(date) Backup: Complete"
```

---

## File 12: `scripts/restore-session.sh`

```bash
#!/bin/bash
set -euo pipefail

BACKUP_DIR="/home/androidusr/backup"

if [ ! -f "${BACKUP_DIR}/session-manifest.json" ]; then
    echo "$(date) Restore: No previous session - fresh start"
    exit 0
fi

SESSION_ID=$(jq -r '.session_id' "${BACKUP_DIR}/session-manifest.json" 2>/dev/null || echo "unknown")
echo "$(date) Restore: Found session ${SESSION_ID}"

AVD_BACKUP=$(ls "${BACKUP_DIR}"/avd-data*.tar.gz 2>/dev/null | head -1)
if [ -n "${AVD_BACKUP}" ] && [ -f "${AVD_BACKUP}" ]; then
    tar xzf "${AVD_BACKUP}" -C /root/.android/ 2>/dev/null || true
    echo "  AVD data restored"
fi

echo "$(date) Restore: Complete"
```

---

## File 13: `start.sh`

```bash
#!/bin/bash
set -euo pipefail

NO_TUNNEL=false
while [[ $# -gt 0 ]]; do
    case $1 in
        --no-tunnel) NO_TUNNEL=true; shift ;;
        *) shift ;;
    esac
done

echo "☁️ Cloud Android Phone v2.0"
echo "=============================="

if ! command -v docker &>/dev/null; then
    echo "✗ Docker required. Install: https://docs.docker.com/get-docker/"
    exit 1
fi

[ -e /dev/kvm ] && sudo chmod 666 /dev/kvm 2>/dev/null || true

echo "Building image..."
docker build -t cloud-android-phone:latest .

echo "Starting container..."
docker run -d \
    --name cloud-phone \
    --privileged \
    --device /dev/kvm:/dev/kvm \
    -p 8000:8000 \
    -p 5555:5555 \
    -e DISPLAY_WIDTH=720 \
    -e DISPLAY_HEIGHT=1280 \
    -e RAM_SIZE=4096 \
    -e SCRCPY_WEB_PORT=8000 \
    -e ARM_TRANSLATION=1 \
    -e ROOT_SETUP=1 \
    -e GAPPS_SETUP=1 \
    -e SESSION_MAX_HOURS=6 \
    cloud-android-phone:latest

echo "Waiting for boot..."
for i in $(seq 1 300); do
    BOOT=$(docker exec cloud-phone /opt/android-sdk/platform-tools/adb -s emulator-5555 shell getprop sys.boot_completed 2>/dev/null || echo "0")
    if [ "${BOOT}" = "1" ]; then
        echo "✓ Boot complete after $((i * 2))s"
        break
    fi
    [ $i -eq 90 ] && echo "  ... 3 min"
    [ $i -eq 180 ] && echo "  ... 6 min"
    sleep 2
done

TUNNEL_URL="http://localhost:8000"
if [ "${NO_TUNNEL}" = "false" ]; then
    npm install -g nport 2>/dev/null || npm install -g --force nport
    SUB="caphone-$(date +%s | sha256sum | head -c 6)"
    nport 8000 -s "${SUB}" > /tmp/nport-cp.log 2>&1 &
    for i in $(seq 1 30); do
        sleep 3
        if grep -q "nport.link" /tmp/nport-cp.log 2>/dev/null; then
            TUNNEL_URL=$(grep -oP 'https://[a-zA-Z0-9.-]+\.nport\.link' /tmp/nport-cp.log | head -1)
            break
        fi
    done
fi

echo ""
echo "╔══════════════════════════════════════════════════════════════════╗"
echo "║   🎉  READY! URL: ${TUNNEL_URL}                                ║"
echo "║   Open in any browser to use your Cloud Android Phone           ║"
echo "╚══════════════════════════════════════════════════════════════════╝"
echo ""
echo "Stop:  ./stop.sh"
echo "Logs:  docker logs -f cloud-phone"
```

---

## File 14: `stop.sh`

```bash
#!/bin/bash
set -euo pipefail

echo "🧹 Stopping Cloud Android Phone..."

mkdir -p /tmp/cloud-phone-backup
docker exec cloud-phone tar czf - /home/androidusr/backup > /tmp/cloud-phone-backup/session.tar.gz 2>/dev/null || true
docker exec cloud-phone /opt/android-sdk/platform-tools/adb -s emulator-5555 shell pm list packages > /tmp/cloud-phone-backup/packages.txt 2>/dev/null || true

pkill -f "nport.*8000" 2>/dev/null || true
docker stop cloud-phone 2>/dev/null || true
docker rm cloud-phone 2>/dev/null || true

echo "✓ Stopped. Backup in /tmp/cloud-phone-backup/"
```

---

## File 15: `.dockerignore`

```
.git
.github
.gitlab-ci.yml
.gitignore
README.md
docs/
*.md
backup/
*.tar.gz
node_modules/
*.log
```

---

## File 16: `.gitignore`

```
node_modules/
*.log
backup/
data/
*.tar.gz
*.zip
.env
.DS_Store
```

---

## File 17: `config/ws-scrcpy-config.json`

```json
{
  "serverPort": 8000,
  "serverHost": "0.0.0.0",
  "wsHost": "0.0.0.0",
  "wsPort": 8001,
  "adbPath": "/opt/android-sdk/platform-tools/adb",
  "adbHost": "emulator-5555",
  "adbPort": 5555,
  "devices": {
    "firstMatch": []
  },
  "codecOptions": {
    "bitrate": 4000000,
    "maxFps": 60,
    "maxSize": 0
  },
  "streaming": {
    "preferredEngine": "h264Converter",
    "fallbackEngine": "broadway.js"
  },
  "authentication": {
    "enabled": false
  }
}
```

---

## How to Deploy from Termux

1. **Create the project:**
   ```bash
   mkdir -p ~/cloud-phone/.github/workflows ~/cloud-phone/config ~/cloud-phone/scripts
   ```

2. **Create each file** using `cat > filename << 'EOF'` with the content above.

3. **Initialize git and push:**
   ```bash
   cd ~/cloud-phone
   git init
   git add .
   git commit -m "Cloud Android Phone v2.0"
   git remote add origin https://github.com/YOUR_USERNAME/cloud-phone.git
   git push -u origin main
   ```

4. **Go to GitHub** → Your repo → Actions → Run workflow → Watch the URL appear!

---

*PhantomLink Operations — Professional Cloud Android Infrastructure*
