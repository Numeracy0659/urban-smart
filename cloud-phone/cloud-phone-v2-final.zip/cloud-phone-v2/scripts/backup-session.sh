#!/bin/bash
###############################################################################
# Cloud Android Phone - Session Backup Script
# Compresses and optionally encrypts session data for persistence
###############################################################################

set -euo pipefail

BACKUP_DIR="/home/androidusr/backup"
ADB=/opt/android-sdk/platform-tools/adb
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
SESSION_ID="${SESSION_ID:-$(date +%s | sha256sum | head -c 8)}"

mkdir -p "${BACKUP_DIR}"

echo "$(date) Backup: Starting session backup [${SESSION_ID}]"

# ─── Backup ADB Settings ──────────────────────────────────────────────────
echo "  Backing up system settings..."
mkdir -p "${BACKUP_DIR}/settings"
"${ADB}" -s emulator-5555 shell settings list global > "${BACKUP_DIR}/settings/global.txt" 2>/dev/null || true
"${ADB}" -s emulator-5555 shell settings list system > "${BACKUP_DIR}/settings/system.txt" 2>/dev/null || true
"${ADB}" -s emulator-5555 shell settings list secure > "${BACKUP_DIR}/settings/secure.txt" 2>/dev/null || true

# ─── Backup Installed Packages ───────────────────────────────────────────
echo "  Backing up package list..."
"${ADB}" -s emulator-5555 shell pm list packages > "${BACKUP_DIR}/packages.txt" 2>/dev/null || true

# ─── Backup AVD Data ─────────────────────────────────────────────────────
echo "  Backing up AVD data..."
if [ -d /root/.android/avd ]; then
    tar czf "${BACKUP_DIR}/avd-data-${SESSION_ID}.tar.gz" \
        -C /root/.android avd/ 2>/dev/null || true
fi

# ─── Create Session Manifest ─────────────────────────────────────────────
cat > "${BACKUP_DIR}/session-manifest.json" <<EOF
{
  "session_id": "${SESSION_ID}",
  "backup_time": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "android_version": "14 (API 34)",
  "device": "pixel_6",
  "resolution": "${DISPLAY_WIDTH}x${DISPLAY_HEIGHT}",
  "packages": $(wc -l < "${BACKUP_DIR}/packages.txt" 2>/dev/null || echo 0),
  "size_bytes": $(du -sb "${BACKUP_DIR}" | cut -f1 2>/dev/null || echo 0)
}
EOF

echo "$(date) Backup: Complete - ${BACKUP_DIR}/session-manifest.json"
echo "  Session ID: ${SESSION_ID}"
ls -lh "${BACKUP_DIR}/"
