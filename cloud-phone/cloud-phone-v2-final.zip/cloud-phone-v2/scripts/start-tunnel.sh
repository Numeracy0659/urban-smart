#!/bin/bash
###############################################################################
# Cloud Android Phone - NPort Tunnel Startup
# Creates a public HTTPS tunnel to the ws-scrcpy web interface
###############################################################################

set -euo pipefail

PORT="${SCRCPY_WEB_PORT:-8000}"
SESSION_ID="${SESSION_ID:-$(date +%s | sha256sum | head -c 6)}"
SUBDOMAIN="caphone-${SESSION_ID}"

# Wait for ws-scrcpy to be ready
echo "$(date) Tunnel: Waiting for ws-scrcpy server..."
for i in $(seq 1 60); do
    if curl -s -o /dev/null -w "%{http_code}" "http://localhost:${PORT}" 2>/dev/null | grep -qE "^[2-4]"; then
        echo "$(date) Tunnel: ws-scrcpy server is ready"
        break
    fi
    sleep 3
done

# Start NPort tunnel
echo "$(date) Tunnel: Starting NPort tunnel..."
exec nport "${PORT}" -s "${SUBDOMAIN}" 2>&1
