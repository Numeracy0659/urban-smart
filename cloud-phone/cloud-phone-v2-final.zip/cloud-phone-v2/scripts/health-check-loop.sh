#!/bin/bash
###############################################################################
# Cloud Android Phone - Health Check Loop
# Continuously monitors system health
###############################################################################

set -euo pipefail

ADB=/opt/android-sdk/platform-tools/adb
PORT="${SCRCPY_WEB_PORT:-8000}"
INTERVAL=30

echo "$(date) Health Check: Starting monitoring loop (interval: ${INTERVAL}s)"

while true; do
    # Check ADB
    ADB_STATUS="OK"
    if ! "${ADB}" devices 2>/dev/null | grep -q "List of devices"; then
        ADB_STATUS="FAIL"
    fi

    # Check Emulator
    EMU_STATUS="OK"
    if ! "${ADB}" -s emulator-5555 shell getprop sys.boot_completed 2>/dev/null | grep -q "1"; then
        EMU_STATUS="FAIL"
    fi

    # Check Web Server
    WEB_STATUS="OK"
    HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:${PORT}" 2>/dev/null || echo "000")
    if ! echo "${HTTP_CODE}" | grep -qE "^[2-4]"; then
        WEB_STATUS="FAIL"
    fi

    # Check Tunnel
    TUNNEL_STATUS="OK"
    if [ -f /home/androidusr/logs/nport.log ]; then
        if ! grep -q "nport.link" /home/androidusr/logs/nport.log 2>/dev/null; then
            TUNNEL_STATUS="WAITING"
        fi
    fi

    # Log status
    echo "$(date) Health: ADB=${ADB_STATUS} | Emulator=${EMU_STATUS} | Web=${WEB_STATUS} | Tunnel=${TUNNEL_STATUS}"

    # Restart failed services via supervisorctl
    if [ "${ADB_STATUS}" = "FAIL" ]; then
        "${ADB}" start-server 2>/dev/null || true
    fi

    sleep "${INTERVAL}"
done
