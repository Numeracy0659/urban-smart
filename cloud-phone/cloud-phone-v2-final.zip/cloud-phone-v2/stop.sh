#!/bin/bash
###############################################################################
# Cloud Android Phone - Stop Script
# PhantomLink Operations - Production v2.0
###############################################################################

set -euo pipefail

echo ""
echo "╔══════════════════════════════════════════════════════════════════╗"
echo "║   🧹  Cloud Android Phone - Stopping                            ║"
echo "╚══════════════════════════════════════════════════════════════════╝"
echo ""

# Backup
echo "💾 Backing up session state..."
mkdir -p /tmp/cloud-phone-backup
docker exec cloud-phone tar czf - /home/androidusr/backup > /tmp/cloud-phone-backup/session.tar.gz 2>/dev/null || true
docker exec cloud-phone /opt/android-sdk/platform-tools/adb -s emulator-5555 shell settings list global > /tmp/cloud-phone-backup/settings-global.txt 2>/dev/null || true
docker exec cloud-phone /opt/android-sdk/platform-tools/adb -s emulator-5555 shell pm list packages > /tmp/cloud-phone-backup/packages.txt 2>/dev/null || true
echo "  ✓ Saved to /tmp/cloud-phone-backup/"
echo ""

# Stop tunnel
echo "🔒 Stopping tunnel..."
pkill -f "nport.*8000" 2>/dev/null || true
echo "  ✓ Tunnel stopped"
echo ""

# Stop container
echo "⏹️  Stopping container..."
docker stop cloud-phone 2>/dev/null || true
docker rm cloud-phone 2>/dev/null || true
echo "  ✓ Container stopped"
echo ""

echo "╔══════════════════════════════════════════════════════════════════╗"
echo "║   ✓  Cloud Android Phone stopped                                 ║"
echo "║   Session data preserved in /tmp/cloud-phone-backup/            ║"
echo "║   To restore, run: ./start.sh                                   ║"
echo "╚══════════════════════════════════════════════════════════════════╝"
echo ""
