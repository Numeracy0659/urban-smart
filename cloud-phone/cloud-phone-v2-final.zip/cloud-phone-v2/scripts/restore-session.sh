#!/bin/bash
###############################################################################
# Cloud Android Phone - Session Restore Script
# Restores session data from a previous backup
###############################################################################

set -euo pipefail

BACKUP_DIR="/home/androidusr/backup"
ADB=/opt/android-sdk/platform-tools/adb

echo "$(date) Restore: Checking for previous session..."

# Check if backup exists
if [ ! -f "${BACKUP_DIR}/session-manifest.json" ]; then
    echo "$(date) Restore: No previous session found - starting fresh"
    exit 0
fi

# Read session info
SESSION_ID=$(jq -r '.session_id' "${BACKUP_DIR}/session-manifest.json" 2>/dev/null || echo "unknown")
echo "$(date) Restore: Found session ${SESSION_ID}"

# Restore ADB settings
echo "  Restoring system settings..."
for setting_file in "${BACKUP_DIR}/settings/"*.txt; do
    if [ -f "${setting_file}" ]; then
        namespace=$(basename "${setting_file}" .txt)
        while IFS= read -r line; do
            if [[ "${line}" == *("=")* ]]; then
                key=$(echo "${line}" | cut -d'=' -f1 | tr -d '[:space:]')
                value=$(echo "${line}" | cut -d'=' -f2- | tr -d '[:space:]')
                "${ADB}" -s emulator-5555 shell settings put "${namespace}" "${key}" "${value}" 2>/dev/null || true
            fi
        done < "${setting_file}"
    fi
done

# Restore AVD data
echo "  Restoring AVD data..."
AVD_BACKUP=$(ls "${BACKUP_DIR}"/avd-data-*.tar.gz 2>/dev/null | head -1)
if [ -n "${AVD_BACKUP}" ] && [ -f "${AVD_BACKUP}" ]; then
    tar xzf "${AVD_BACKUP}" -C /root/.android/ 2>/dev/null || true
    echo "  ✓ AVD data restored"
fi

echo "$(date) Restore: Complete - Session ${SESSION_ID} restored"
