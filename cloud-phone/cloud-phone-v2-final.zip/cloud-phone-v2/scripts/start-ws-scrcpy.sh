#!/bin/bash
###############################################################################
# Cloud Android Phone - ws-scrcpy Web Server Startup
# Starts the WebSocket-based screen mirroring server
###############################################################################

set -euo pipefail

ADB=/opt/android-sdk/platform-tools/adb
PORT="${SCRCPY_WEB_PORT:-8000}"

# Wait for emulator to be ready
echo "$(date) ws-scrcpy: Waiting for ADB device..."
while ! "${ADB}" -s emulator-5555 shell getprop sys.boot_completed 2>/dev/null | grep -q "1"; do
    sleep 5
done
echo "$(date) ws-scrcpy: Android boot completed"

# Connect ADB to device
"${ADB}" -s emulator-5555 tcpip 5555 2>/dev/null || true
sleep 2

# Start ws-scrcpy server
cd /opt/ws-scrcpy

# Set ADB host to connect to emulator
export ADBHOST=emulator-5555

# Start the web server
exec node dist/index.js --port "${PORT}" --host 0.0.0.0 2>&1
